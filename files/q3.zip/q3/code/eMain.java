
public class eMain {

 public static void main(String[] args) {

 // Enhance the Person class if necessary:
 com.objectdb.Enhancer.enhance("Person");

 // Now run the real main:
 JDOTest.main(args);
 }
 }